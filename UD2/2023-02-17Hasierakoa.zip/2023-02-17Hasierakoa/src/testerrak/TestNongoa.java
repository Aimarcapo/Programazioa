package testerrak;

import java.util.Arrays;

import model.Nongoa;

public class TestNongoa {
    public static void main(String[] args) {
        
        System.out.println(Arrays.toString(Nongoa.values()));
    }
}
