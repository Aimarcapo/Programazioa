
/** Erabiltzaileak adierazitako kalkulua egingo du programa honek. 
 * Mota honetako eragiketak egiteko gai izan behar da: 
 * 1/2 x 1/2 x 1/2 x 1/2 = 1/16
 * 11/2 x 2/11 x -4/5 = -4/5
 */

public class Kalkulagailua {
    public static void main(String[] args) {
   
    }
}
